function imgDisplay()
{
    if(document.getElementById('bar').checked)
    {
        document.getElementById('display').src = "static/images/revenue_bar_data.png"
    }
    else
    if(document.getElementById('line').checked)
    {
        document.getElementById('display').src = "static/images/revenue_line_data.png"
    }
}

function f(){
    var y = '{{data.previ}}'
    alert(y)
    var x = "{{pre}}"
    alert(x)
}