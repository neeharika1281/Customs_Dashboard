from django.shortcuts import render
import pandas as pd
import matplotlib.pyplot as plt
from django.http import HttpResponse
# Create your views here.

def index(request):
    # Welcome page
    return render(request,'dashboard/home.html')

def Revenue(request):
    # reading the data from excel
    data = pd.read_excel(r'Customs_Revenue_Data.xlsx',"Sheet1")
    df = pd.DataFrame(data)
    original_data =  pd.DataFrame(data)

    # dropping the last total column for easy creation of graphs
    df.drop(df.tail(1).index,inplace=True)

    # changing the columns names because the column names are dynamic
    change_column_name = {df.columns[1]:'previ',df.columns[2]:'pre'}
    df5= original_data.rename(columns = change_column_name, inplace = False)
    df4 = df.rename(columns = change_column_name, inplace = False)

    # filling nan values with 0 for easy calculation
    df4["pre"].fillna(0, inplace = True)

    # converting the dataframes to lists
    prey = df4['pre'].tolist()
    previy = df4['previ'].tolist()
    months_la = df4['Month'].tolist()
    prey_line = df4['pre'].tolist()

    # counting the no.of nan values in this case 0's and popping them out of the list
    count=0
    for i in prey_line:
        if(i==0.0):
            count+=1
    while count:
        prey_line.remove(0.0)
        count-=1            
    insert_data =[]

    # appending all the excel data in the form of dictionary to insert_data, which is displayed as a table in the html page
    for i in range(df5.shape[0]):
        temp = df5.loc[i]
        insert_data.append(dict(temp))
    
    #context is a dictionary which is rendered and can be accessed in html by using jinja code 
    context = {'data':insert_data,'month':df.columns[0],'previous_year':df.columns[1],'present_year':df.columns[2],'prey':prey,'previy':previy,'monthsl':months_la,'prey_line':prey_line}

    return render(request,'dashboard/task1.html',context)    

def Top_10_import_items(request):
    # reading the data from excel
    data = pd.read_excel(r'Customs_Revenue_Data.xlsx',"Sheet2")
    df = pd.DataFrame(data)
    insert_data =[]
    df_dup = pd.DataFrame(data)

    # changing the columns names because the column names are dynamic
    change_column_name = {df_dup.columns[1]:'cth',df_dup.columns[2]:'prev_revenue',df_dup.columns[3]:'prev_qty',df_dup.columns[4]:'prev_val',
                                 df_dup.columns[5]:'avg_price',df_dup.columns[6]:'duty_rate'}    
    df_dup= df_dup.rename(columns = change_column_name, inplace = False)

    # appending all the excel data in the form of dictionary to insert_data
    for i in range(df.shape[0]):
        temp = df_dup.loc[i]
        insert_data.append(dict(temp))
    
    #context is a dictionary which is rendered and can be accessed in html by using jinja code 
    context = {'data':insert_data,'S.NO':df.columns[0],'CTH':df.columns[1],'prev_rev':df.columns[2],'prev_qty':df.columns[3],'prev_val':df.columns[4],
                    'AvgPrice':df.columns[5],'DutyRate':df.columns[6]}
                    
    return render(request,'dashboard/task2.html',context)

def calculate(request):
        # excel reading 
        data = pd.read_excel(r'Customs_Revenue_Data.xlsx',"Sheet2")
        df = pd.DataFrame(data)
        insert_data =[]
        df_dup = pd.DataFrame(data)

        # changing the columns names because the column names are dynamic
        change_column_name = {df_dup.columns[1]:'cth',df_dup.columns[2]:'prev_revenue',df_dup.columns[3]:'prev_qty',df_dup.columns[4]:'prev_val',
                                    df_dup.columns[5]:'avg_price',df_dup.columns[6]:'duty_rate'}    
        df_dup= df_dup.rename(columns = change_column_name, inplace = False)

        # appending all the excel data in the form of dictionary to insert_data
        for i in range(df.shape[0]):
            temp = df_dup.loc[i]
            insert_data.append(dict(temp))

        context = {'data':insert_data,'S.NO':df.columns[0],'CTH':df.columns[1],'prev_rev':df.columns[2],'prev_qty':df.columns[3],'prev_val':df.columns[4],
                        'AvgPrice':df.columns[5],'DutyRate':df.columns[6]} 
        previous_revenue = df_dup['prev_revenue']
        previous_qty = df_dup['prev_qty']
        Avg_price = df_dup['avg_price']
        rate_of_duty = df_dup['duty_rate']

        # reading form data and calculating the expected revenue            
        if request.method == 'POST':
            form_data = request.POST
            expected_qty = []
            expected_price = []
            qty = []
            price = []
            new_rev = previous_revenue.copy()

            for x,y in form_data.items():
                if(x[-1]=='q'):
                    if y=='':
                        qty.append(y)
                        y = -1
                    else:
                        y = float(y)
                        qty.append(y)    
                    expected_qty.append(y)
                elif(x[-1]=='v'):
                    if y=='':
                        price.append(y)
                        y = -1
                    else:
                        y = float(y) 
                        price.append(y)
                    expected_price.append(y)
            context['qty'] = qty
            context['price'] = price
            context['table_data'] = zip(qty,price)

            # calculating the expected revenue based upon the given expected top 10 import values    
            for i in range(10):
                if(expected_qty[i]==-1 and expected_price[i]==-1):
                    x = previous_revenue[i]
                    new_rev[i] = x
                elif(expected_qty[i]!=-1 and expected_price[i]!=-1):
                    qty = expected_qty[i]
                    price = expected_price[i]
                    x = qty*price
                    x/=1e7
                    x*=rate_of_duty[i]
                    new_rev[i] = x-previous_revenue[i]      
                elif(expected_price[i]==-1):
                    qty = expected_qty[i]
                    x = qty*Avg_price[i]
                    x/=1e7
                    x *= rate_of_duty[i]
                    new_rev[i] = x-previous_revenue[i]
                elif(expected_qty[i]==-1):
                    qty = previous_qty[i]
                    x = qty*expected_price[i]
                    x/=1e7
                    x*=rate_of_duty[i]
                    new_rev[i] = x-previous_revenue[i]

            # reading previous year revenue collection from sheet1 in excel sheet i.e the total revenue from Revenue
            task1_data = pd.read_excel(r'Customs_Revenue_Data.xlsx',"Sheet1")
            df_task1 = pd.DataFrame(task1_data)  
            previous_year = df_task1.columns[1]
            context['prev'] = previous_year
            present_year = df_task1.columns[2]
            context['pre'] = present_year
            rev = df_task1.iloc[-1,1]
            context['previous_year_revenue'] = rev
            context['present_year_revenue'] = round(rev+(sum(new_rev)-sum(previous_revenue)),2) 
                         
        return render(request,'dashboard/task2_cal.html',context)    